/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocaball <jocaball@student.42malaga.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/06 21:47:38 by jocaball          #+#    #+#             */
/*   Updated: 2023/02/08 01:18:53 by jocaball         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdio.h>

int	ft_strlen(char *str);

int	main(void)
{
	int	len;

	len = ft_strlen("");
	printf("%d - ", len);
	len = ft_strlen("Hello world! How are you?");
	printf("%d", len);
	return (0);
}
