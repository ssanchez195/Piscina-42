/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocaball <jocaball@student.42malaga.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/04 20:47:57 by jocaball          #+#    #+#             */
/*   Updated: 2023/02/05 04:20:45 by jocaball         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include        <unistd.h>

void	ft_putnbr(int nb);

int	main(void)
{
	ft_putnbr(0x80000000);
	write (1, "\n", 1);
	ft_putnbr(0x7fffffff);
	write (1, "\n", 1);
	ft_putnbr(-2023);
	write (1, "\n", 1);
	ft_putnbr(42);
	return (0);
}
