/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocaball <jocaball@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/04 20:47:57 by jocaball          #+#    #+#             */
/*   Updated: 2023/02/16 11:52:51 by jocaball         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>


void	ft_putnbr(int nb);
int		ft_atoi(char *str);

int	main(void)
{
	char	*str;

	str = "    ---+---+-a1234abfr567-";
	printf("%d\n", ft_atoi(str));
	str = "    ---+---+--1234abfr567-";
	printf("%d\n", ft_atoi(str));
	str = "    ---+--+--1234abfr567-";
	printf("%d\n", ft_atoi(str));
	return (0);
}