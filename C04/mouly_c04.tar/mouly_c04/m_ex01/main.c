/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocaball <jocaball@student.42malaga.com>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/06 21:47:38 by jocaball          #+#    #+#             */
/*   Updated: 2023/02/07 12:42:23 by jocaball         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	<stdio.h>

void	ft_putstr(char *str);

int	main(void)
{
	ft_putstr("Hola mundo! Cómo estás?");
	return (0);
}
