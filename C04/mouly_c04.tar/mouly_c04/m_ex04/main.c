/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jocaball <jocaball@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/04 20:47:57 by jocaball          #+#    #+#             */
/*   Updated: 2023/02/16 18:52:12 by jocaball         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>		

void	ft_putnbr_base(int nbr, char *base);

int	main(void)
{
	char	*base;
	int		nbr;

	base = "0123456789abcdef";
	nbr = -2147483648;
	ft_putnbr_base(nbr, base);
	write (1, "\n", 1);
	base = "01";
	nbr = -2147483648;
	ft_putnbr_base(nbr, base);
	write (1, "\n", 1);
	base = "qwerty";
	nbr = 12345;
	ft_putnbr_base(nbr, base);
	return (0);
}
